﻿
namespace PetSpeak.Service.Models

{
    public class AttachmentServiceModel : BaseServiceModel
    {
        public string CloudUrl { get; set; }
    }
}
