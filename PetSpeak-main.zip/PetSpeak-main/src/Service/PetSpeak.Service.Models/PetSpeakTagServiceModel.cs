﻿using PetSpeak.Data.Models;
namespace PetSpeak.Service.Models
{
    public class PetSpeakTagServiceModel : MetadataBaseServiceModel
    {
        public string Label { get; set; }
    }
}
