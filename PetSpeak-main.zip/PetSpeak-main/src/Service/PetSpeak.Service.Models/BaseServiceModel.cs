﻿namespace PetSpeak.Service.Models
{
    public abstract class BaseServiceModel
    {
        public string Id { get; set; }
    }
}
