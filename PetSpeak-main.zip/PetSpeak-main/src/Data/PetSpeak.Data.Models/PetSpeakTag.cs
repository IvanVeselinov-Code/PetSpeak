﻿namespace PetSpeak.Data.Models
{
    public class PetSpeakTag : MetadataBaseEntity
    {
        public string Label { get; set; }
        public string CreatedById { get; set; }

    }
}
