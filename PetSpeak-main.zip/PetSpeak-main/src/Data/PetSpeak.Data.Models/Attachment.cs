﻿namespace PetSpeak.Data.Models
{
    public class Attachment : BaseEntity
    {
        public string CloudUrl { get; set; }
    }
}
