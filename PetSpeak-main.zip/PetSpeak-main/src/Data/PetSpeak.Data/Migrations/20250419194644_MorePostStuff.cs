﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PetSpeak.Web.Data.Migrations
{
    /// <inheritdoc />
    public partial class MorePostStuff : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
